var express = require('express');
var router = express.Router();
var connection=require('../model/dbconnect');
/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('adminhome');
});
router.get('/add', function(req, res, next) {
  res.render('login/firstpage', { title: 'admin' });
});

module.exports = router;
