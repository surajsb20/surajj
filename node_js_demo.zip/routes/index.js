var express = require('express');
var router = express.Router();
var connection=require('../model/dbconnect');
var element=require('../model/icecream');
var i_menu=require('../model/menumodel');
var async=require('async');
var news=require('../model/newsmodel');

var path=require('path');
//var homecontroll=require('../controller/home');
/* GET home page. */
router.get('/', function(req, res, next) {
   //var data=getmenu(connection)
   {
       var dd;
     console.log(path);
     
        async.waterfall([function getnews(callback){
               
        news.news( connection,function(result){callback(null,result);});
     
        }],function(err,result){
  res.render('myindex', { title: 'Icecream',hh:'Home',news:result });    
});
 
  
   }
 
  

  
});



router.post('/adminlogin/loginto', function(req, res, next) {
  
  var username=req.body.username;
  var pswd=req.body.pwsd;
      console.log(username+' '+pswd);
  connection.query("select * from admin  where username='"+username+"' and pswd='"+pswd+"' ",function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    if(result.length==1){
        var sess=req.session;
            console.log('login succesfful');
            sess.adminuser='1';
            console.log(sess.adminuser);
            res.redirect('/adminhome');
    }else{
        res.render('loginindex', { title: 'Icecream' ,hh:'Admin Login',status:1});
    }
  });
 // res.render('loginindex', { title: 'Icecream' ,hh:'Admin Login'});
});

router.get('/adminlogin', function(req, res, next) {
  var error=req.params.error;
  if(error=='1'){
      console.log('invalid');
  }
  res.render('loginindex', { title: 'Icecream' ,hh:'Admin Login',status:0});
});
router.get('/contact', function(req, res, next) {
  res.render('contact', { title: 'Icecream' ,hh:'Contact'});
});
router.get('/menu', function(req, res, next) {
    
    console.log('ss');
           
        async.waterfall([function getitem(callback){
             
                i_menu.menu(connection,function(result){   callback(null,result);});
               
        },function(arg,callback){
              
            i_menu.category(connection,function(result){   
            
                var mresult={a:arg,b:result}
                callback(null,mresult);});
               
            
        }],function(err,result){console.log(result)
 res.render('menu', { title: 'Icecream' ,hh:'Menu',data:result});    
});
 
});
router.get('/about', function(req, res, next) {
   
     res.render('about', { title: 'Icecream' ,hh:'About'});

  //res.render('myindex', { title: 'Express' ,hh:"Icecream"});
  
});
router.post('/savecontact',function(req, res, next) {
  
    if(connection)

{
    
    var name=req.body.name;
    var email=req.body.email;
    var subject=req.body.subject;
    var  msg=req.body.message;
    var value=[[name,email,subject,msg]];
      console.log(value);  
  
    var sql = "INSERT INTO  contact(name,email,subject,msg) VALUES ?";
   connection.query(sql,[value],function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");

  
  });
  }else{}
  res.render('contact', { title: 'Icecream' ,hh:'Contact'});
});


module.exports = router;
