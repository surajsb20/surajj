/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




var express = require('express');
var router = express.Router();
var connection=require('../model/dbconnect');

var session = require('express-session');
var news=require('../model/newsmodel');
var mailer=require('nodemailer');
var emailfunct=require('../model/emailsender');
/* GET users listing. */


router.get('/', function(req, res, next) {
      var sql = "SELECT * FROM  contact ";
     connection.query(sql,function (err, result) {
    if (err) throw err;
  var data=result;
  console.log()
  if(req.session.adminuser){
  res.render('homeindex', { title: 'admin' ,contact:data});
  }else{res.send('invalid');}
    console.log("1 record inserted");

  
  });
  
});



router.get('/add', function(req, res, next) {
  if(req.session.adminuser){}else{
      res.redirect('/');
  }

      res.render('adminadd', { title: 'admin' ,'hh':'Add' });});
  
router.get('/view',function(req, res, next){
      if(req.session.adminuser){}else{
      res.redirect('/');
  }

  connection.query("SELECT * FROM icecream_dt", function (err, result, fields) {
    if (err) throw err;
    var data= result;
  
  res.render('adminview', { title: 'admin' ,'hh':'View' ,data:data});
  
});
    
});
router.post('/save', function(req, res, next) {
      if(req.session.adminuser){}else{
      res.redirect('/');
  }

var name=req.body.menuname;
var category=req.body.categoryname;
var price=req.body.price;
var detail=req.body.detail;
  
if(connection)

{
    
    
    console.log(connection);
    var sql = "INSERT INTO icecream_dt (name,category,detail,price) VALUES ?";
    
   var values = [[name, category,detail,price]];
  connection.query(sql,[values],function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");

  
  });}else{}
});


router.get('/update', function(req, res, next) {
    if(req.session.adminuser){}else{
      res.redirect('/');
  }


  res.render('admin/update', { title: 'admin' });

});

router.post('/getupdate', function(req, res, next) {
var mid=req.body.id;
var sql="SELECT * FROM icecream_dt WHERE id='"+mid+"' ";
connection.query(sql,function (err, result) {
    if (err) throw err;
    console.log("1 selected");
var mdata=result;
console.log(mdata);
  res.render('admin/update', { id:mid,data:mdata});
  
  });
});
router.get('/logout',function(req,res,next){
    
    
});

router.post('/updatesave', function(req, res, next) {
var id=req.body.mkip;
var name=req.body.menuname;
var category=req.body.categoryname;
var price=req.body.price;
var detail=req.body.detail;
var sql = "UPDATE icecream_dt SET name = '"+name+"',category = '"+category+"' ,detail = '"+detail+"' ,price = '"+price+"' WHERE id ='"+id+"'";    
   var values = [[name, category,detail,price]];
  connection.query(sql,[values],function (err, result) {
    if (err) throw err;
    console.log("updated");

  res.render("redirectto",{toredirect:"/adminhome/"});
  });
console.log();
});

router.get('/logoutto', function(req, res, next) {
 req.session.destroy();
 res.render("redirectto",{toredirect:"/"});
 next();
});

router.get('/news',function(req,res,next){
      if(req.session.adminuser){}else{
      res.redirect('/');
  }

    news.news(connection,function(result){
      console.log(result);
        res.render("admin/news",{news:result, title: 'admin' });
        
    });
    
});

router.post('/newsdel',function(req,res,next){
var id=req.body.mkey;
console.log(id);
    news.deletenews(connection,id,function(result){
      console.log(result);
      res.redirect('/adminhome/news');
       
    });
    
});

router.post('/deletecontact',function(req,res,next){
var id=req.body.mkey;
console.log(id);
    news.delcontact(connection,id,function(result){
      console.log(result);
      res.redirect('/adminhome/contact');
       
    });
    
});
router.post('/sendemail',function(req,res,next){
var id=req.body.mkey;
var subject=req.body.subject;
var msg=req.body.msg;
var email=req.body.email;
   var transporter = mailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'suraj69sb@gmail.com',
    pass: ''
  }
});

var mailOptions = {
  from: 'suraj69sb@gmail.com',
  to: email,
  subject: subject,
  text: msg
};
console.log(mailOptions);
emailfunct.mailsend(transporter,mailOptions,function(result){
    news.sendstatus(connection,id,function(result){console.log(result);})
    res.redirect('adminhome/contact');
});
});

router.get('/contact',function(req,res,next){
      if(req.session.adminuser){}else{
      res.redirect('/');
  }

    var title=req.body.title;
    var date=req.body.date;
    var detail=req.body.detail;
    var data=[[title,date,detail]];
    console.log(data);

    news.contact(connection,function(result){
      console.log(result);
        res.render("admin/contactview",{contact:result, title: 'admin' });
        
    });
    
});

router.post('/newssave',function(req,res,next){
    var title=req.body.title;
    var date=req.body.date;
    var detail=req.body.detail;
    var data=[[title,date,detail]];
    console.log(data);
    news.insertnews(connection,data,function(){
        res.redirect("/adminhome/news");
    });
    news.news(connection,function(result){
      
        res.render("admin/news",{news:result, title: 'admin' });
        
    });
    
});
module.exports = router;