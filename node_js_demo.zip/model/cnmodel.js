/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




var mysql = require('mysql')
var mysqlm=require('mysql-model')
var connection = mysqlm.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'icecream'
});

//connection.connect();


//connection.query('select * from icecream_dt', function (err, rows, fields) {
  //if (err) throw err

  console.log('connected: ');
  
module.exports = connection;  
//})