

var mysql = require('mysql')
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'icecream'
});

connection.connect();


//connection.query('select * from icecream_dt', function (err, rows, fields) {
  //if (err) throw err

  console.log('connected: ');
  
module.exports = connection;  
//})


