/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function getitem(conn,l){
  
var data;


var sql="SELECT * FROM icecream_dt ";
 conn.query(sql,function (err, result) {
    if (err) throw err;
    data=result;
l(result);
 

  });


  

    
}
function category(conn,callback){
    var sql="SELECT DISTINCT category FROM icecream_dt";
   
 conn.query(sql,function (err, result) {
    if (err) throw err;
data=result;
callback(result);
  
  }); }
  module.exports = {menu:getitem,category:category}; 