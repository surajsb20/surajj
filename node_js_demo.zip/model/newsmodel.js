/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function savenews(conn,data,callback){
    var sql = "INSERT INTO events (title,date,news) VALUES ?";
    
   var values = data;
  conn.query(sql,[values],function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");

  callback();
  });
    
    
}

function getnews(conn,callback){
    var sql="SELECT  * FROM events";
   
 conn.query(sql,function (err, result) {
    if (err) throw err;

callback(result);
  
  }); }

function getcontact(conn,callback){
    var sql="SELECT  * FROM contact";
   
 conn.query(sql,function (err, result) {
    if (err) throw err;

callback(result);
  
  }); }

function mdelete(conn,id,callback){
    
  var sql = "DELETE FROM events WHERE id = '"+id+"'";
  conn.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Number of records deleted: " );
    callback();
  }); }
  function cdelete(conn,id,callback){
    
  var sql = "DELETE FROM contact WHERE id = '"+id+"'";
  conn.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Number of records deleted: " );
    callback();
  }); }
  function sendstatus(conn,id,callback){
      var sql = "UPDATE contact SET status = '1' WHERE id = '"+id+"'";
  conn.query(sql, function (err, result) {
    if (err) throw err;
   callback(result);
  });
      
  }
module.exports = {insertnews:savenews,news:getnews,deletenews:mdelete,contact:getcontact,delcontact:cdelete,sendstatus:sendstatus}; 
 