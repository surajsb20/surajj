var data;
function getdata(con,callback){



var sql="SELECT * FROM icecream_dt ";
 con.query(sql,function (err, result) {
    if (err) throw err;
 callback(result);
  
  });


  
}

function getcontact(con,callback){
  


var sql="SELECT * FROM contact ";
 con.query(sql,function (err, result) {
    if (err) throw err;
    
callback(result);
  
  });

  
}
function vp(con){
  
var sql="SELECT DISTINCT category FROM icecream_dt ";
 con.query(sql,function (err, result) {
    if (err){ throw err;
    }else{
         console.log('returned');
     
       
    }
 console.log('returnedna');
    
  }); 
   return "ss";
}
function getcategory(con,callback){
   

var sql="SELECT DISTINCT category FROM icecream_dt";
 con.query(sql,function (err, result) {
    if (err) throw err;
callback(result);
  
  }); 
}
function a(){
    return "string";
}
function b(c){
    c("jj");
    
}

module.exports = {getdata:getdata,contact:getcontact,vp:vp,pp:function(){return "suraj";},b:b,a:a}; 
 