/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function sendmail(email,data,callback){

email.sendMail(data, function(error, info){
  if (error) {
    console.log(error);
    
  } else {
      callback(info.response);
    console.log('Email sent: ' + info.response);
  }
});}

  module.exports = {mailsend:sendmail}; 