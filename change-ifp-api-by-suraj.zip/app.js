'use strict';
var SwaggerExpress  = require('swagger-express-mw');
var SwaggerUi       = require('swagger-tools/middleware/swagger-ui');
var app             = require('express')();
var log             = require('./api/helpers/logger');
var Response        = require('./api/helpers/response.js');
var jwtHelper       = require('./api/helpers/jwtHelper');
var Acl             = require('acl');
var AclSeq          = require('acl-sequelize');
var db              = require('./api/data/models/index');
var acl             = new Acl(new AclSeq(db.sequelize, {prefix:'acl_'},{sync: true}));
const Routes = require('./api/routes');
const env           = process.env.NODE_ENV || 'development_sqlite';
const envConfig     = require(`${__dirname}/config/config.json`)[env];
app.config          = envConfig;
var bodyParser = require('body-parser')

module.exports      = app;

var config = {
  appRoot: __dirname // required config
};
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(function(req, res, next){
  console.log(req.headers.authorization, "req. headers ");
  next();
});
app.use(Routes);

SwaggerExpress.create(config, function(err, swaggerExpress) {
  if (err) { throw err; }

  app.use(SwaggerUi(swaggerExpress.runner.swagger));

  /*
  app.use(function(req,res,next){
    log.info('*************Interceptor*************');
    let response = new Response();
    let email=null;
    let token=null;
    if(req.headers && req.headers.authorization){
      let auth = req.headers.authorization.split(':');
      if('email'==auth[0]){email=auth[1]}
      if('token'==auth[0]){token=auth[1]}
    }

    if(req.url.includes('jwt') && req.method.toUpperCase()=='POST'){next();}
    else if(req.headers && req.headers.authorization){
        jwtHelper.isValidToken(token)
            .then(function(d){
              req.token=token;
              next();
            })
            .catch(function(e){
              log.info('Error ',e);
              response.instance.error.code=e.code;
              response.instance.error.message=e;
              res.status(e.code).json(response.instance);
            });
    }
    else{res.status(401).json(response.instance);}
  });
  */

  // install middleware
  swaggerExpress.register(app);

  var port = process.env.PORT || 8866;
  app.listen(port);
  console.log('Listening on port ',port);
});
