var log = require('../helpers/logger');
var repo = require('../data/repository/flight.repository');

class FlightService {
  all() {
    log.info(`${this.constructor.name}.all()`);
    return new Promise(
        function(fulfill, reject){
          repo.all()
              .then(function(data){fulfill(data);})
              .catch(function(err){reject(err);});
        });
  }

  byId(id) {
    log.info(`${this.constructor.name}.byId(${id})`);
    return new Promise(
        function(fulfill, reject){
            repo.byId(id)
                .then(function(data){fulfill(data);})
                .catch(function(err){reject(err);});
        });
  }

  create(flight) {
    log.info(`${this.constructor.name}.create(${flight})`);
    return new Promise(
      function(fulfill, reject){
          repo.create(flight)
              .then(function(data){fulfill(data);})
              .catch(function(err){reject(err);});
      });
  }

  update(flightId, flight) {
    log.info(`${this.constructor.name}.update(${flight})`);
    return new Promise(
        function(fulfill, reject){
            repo.update(flightId, flight)
                .then(function(data){fulfill(data);})
                .catch(function(err){reject(err);});
      });
  }

  delete(id){
    log.info(`${this.constructor.name}.update(${id})`);
    return new Promise(
        function(fulfill, reject){
            repo.delete(id)
                .then(function(data){fulfill(data);})
                .catch(function(err){reject(err);});
        });
  }
}

module.exports = new FlightService;