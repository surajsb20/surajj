var log = require('../helpers/logger');
var repo = require('../data/repository/airport.repository');

class AirportService {
  all() {
    log.info(`${this.constructor.name}.all()`);
    return new Promise(
        function(fulfill, reject){
          repo.all()
              .then(function(data){fulfill(data);})
              .catch(function(err){reject(err);});
        });
  }

  byId(id) {
    log.info(`${this.constructor.name}.byId(${id})`);
    return new Promise(
        function(fulfill, reject){
            repo.byId(id)
                .then(function(data){fulfill(data);})
                .catch(function(err){reject(err);});
        });
  }

  create(airport) {
    log.info(`${this.constructor.name}.create(${airport})`);
    return new Promise(
      function(fulfill, reject){
          repo.create(airport)
              .then(function(data){fulfill(data);})
              .catch(function(err){reject(err);});
      });
  }

  update(airportId, airport) {
    log.info(`${this.constructor.name}.update(${airport})`);
    return new Promise(
        function(fulfill, reject){
            repo.update(airportId, airport)
                .then(function(data){fulfill(data);})
                .catch(function(err){reject(err);});
      });
  }

  delete(id){
    log.info(`${this.constructor.name}.update(${id})`);
    return new Promise(
        function(fulfill, reject){
            repo.delete(id)
                .then(function(data){fulfill(data);})
                .catch(function(err){reject(err);});
        });
  }
}

module.exports = new AirportService;