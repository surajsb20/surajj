var log = require('../helpers/logger');
var repo = require('../data/repository/user.repository');

class UserService {
  all() {
    log.info(`${this.constructor.name}.all()`);
    return new Promise(
        function(fulfill, reject){
          repo.all()
              .then(function(d){fulfill(d);})
              .catch(function(e){reject(e);});
        });
  }

  byId(id) {
    log.info(`${this.constructor.name}.byId(${id})`);
    return new Promise(
        function(fulfill, reject){
            repo.byId(id)
                .then(function(d){fulfill(d);})
                .catch(function(e){reject(e);});
        });
  }

  create(user) {
    log.info(`${this.constructor.name}.create(${user})`);
    return new Promise(
      function(fulfill, reject){
          repo.create(user)
              .then(function(d){fulfill(d);})
              .catch(function(e){reject(e);});
      });
  }

  update(id, user) {
    log.info(`${this.constructor.name}.update(${user})`);
    return new Promise(
        function(fulfill, reject){
            repo.update(id, user)
                .then(function(d){fulfill(d);})
                .catch(function(e){reject(e);});
      });
  }

  delete(id){
    log.info(`${this.constructor.name}.update(${id})`);
    return new Promise(
        function(fulfill, reject){
            repo.delete(id)
                .then(function(d){fulfill(d);})
                .catch(function(e){reject(e);});
        });
  }
}

module.exports = new UserService;