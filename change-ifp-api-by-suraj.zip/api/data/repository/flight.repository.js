import log from '../../helpers/logger';

var models      = require('../models');
const db        = require('../models/index');
const fs        = require('fs');

class FlightRepository {
    all() {
        log.info(`${this.constructor.name}.all()`);
        return new Promise(
            function(fulfill, reject){
                models.flights.findAll({})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            }
        );
    }

    byId(id) {
        log.info(`${this.constructor.name}.byId(${id})`);
        return new Promise(
            function(fulfill, reject){
                models.flights.findOne({where: {flightId: id}})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            }
        );
    }

    create(flight) {
        log.info(`${this.constructor.name}.create(${flight})`);
        return new Promise(
            function(fulfill, reject){
                models.flights.create({name:flight.name})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            });
    }

    update(flightId, flight) {
        log.info(`${this.constructor.name}.update(${flight})`);
        return new Promise(
            function(fulfill, reject){
                models.flights.update({name:flight.name}, {where:{flightId:flightId}, returning:true, plain:true})
                    .then(function(data){log.info('*REPO', data); fulfill(data);})
                    .catch(function(err){reject(err);});
            });
    }

    delete(id) {
        log.info(`${this.constructor.name}.delete(${id})`);
        return new Promise(
            function(fulfill, reject){
                models.flights.destroy({where:{FlightID:id}})
                    .then(function(){log.info('Flight('+id+') deleted'); fulfill('SUCCESS');})
                    .catch(function(err){reject(err);});
            });
    }
}

module.exports = new FlightRepository;