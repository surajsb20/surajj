import log from '../../helpers/logger';

var models      = require('../models');
//const db        = require('../models/index');
const fs        = require('fs');

class AirportRepository {
    all() {
        log.info(`${this.constructor.name}.all()`);
        return new Promise(
            function(fulfill, reject){
                models.airports.findAll({})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            }
        );
    }

    byId(id) {
        log.info(`${this.constructor.name}.byId(${id})`);
        return new Promise(
            function(fulfill, reject){
                models.airports.findOne({where: {airportId: id}})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            }
        );
    }

    byCode(code) {
        log.info(`${this.constructor.name}.byCode(${code})`);
        return new Promise(
            function(fulfill, reject){
                models.airports.findOne({where: {aptCode: code}})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            }
        );
    }

    byFaaCode(code) {
        log.info(`${this.constructor.name}.byFaaCode(${code})`);
        return new Promise(
            function(fulfill, reject){
                models.airports.findOne({where: {faaCode: code}})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            }
        );
    }

    byIcaoCode(code) {
        log.info(`${this.constructor.name}.byIcaoCode(${code})`);
        return new Promise(
            function(fulfill, reject){
                models.airports.findOne({where: {icaoCode: code}})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            }
        );
    }

    create(airport) {
        log.info(`${this.constructor.name}.create(${airport})`);
        return new Promise(
            function(fulfill, reject){
                models.airports.create({name:airport.name})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            });
    }

    update(airportId, airport) {
        log.info(`${this.constructor.name}.update(${JSON.stringify(airport)})`);
        return new Promise(
            function(fulfill, reject){
                models.airports.update({name:airport.name}, {where:{facilityId:airportId}})
                    .then(function(data){fulfill(data);})
                    .catch(function(err){reject(err);});
            });
    }

    delete(id) {
        log.info(`${this.constructor.name}.delete(${id})`);
        return new Promise(
            function(fulfill, reject){
                models.airports.destroy({where:{FacilityID:id}})
                    .then(function(){log.info('Airport('+id+') deleted'); fulfill('SUCCESS');})
                    .catch(function(err){reject(err);});
            });
    }
}

module.exports = new AirportRepository;