import log from '../../helpers/logger';

var models      = require('../models');
const db        = require('../models/index');
const fs        = require('fs');

class UserRepository {
    all() {
        log.info(`${this.constructor.name}.all()`);
        return new Promise(
            function(fulfill, reject){
                models.users.findAll({})
                    .then(function(d){fulfill(d);})
                    .catch(function(e){reject(e);});
            }
        );
    }

    byId(id) {
        log.info(`${this.constructor.name}.byId(${id})`);
        return new Promise(
            function(fulfill, reject){
                models.users.findOne({where: {userId: id}})
                    .then(function(d){fulfill(d);})
                    .catch(function(e){reject(e);});
            }
        );
    }

    create(user) {
        log.info(`${this.constructor.name}.create(${user})`);
        return new Promise(
            function(fulfill, reject){
                models.users.create({email:user.email})
                    .then(function(d){fulfill(d);})
                    .catch(function(e){reject(e);});
            });
    }

    update(id, user) {
        log.info(`${this.constructor.name}.update(${JSON.stringify(user)})`);
        return new Promise(
            function(fulfill, reject){
                models.users.update({email:user.email}, {where:{userId:id}})
                    .then(function(d){fulfill(d);})
                    .catch(function(e){reject(e);});
            });
    }

    delete(id) {
        log.info(`${this.constructor.name}.delete(${id})`);
        return new Promise(
            function(fulfill, reject){
                models.users.destroy({where:{userID:id}})
                    .then(function(){log.info('User('+id+') deleted'); fulfill('SUCCESS');})
                    .catch(function(e){reject(e);});
            });
    }
}

module.exports = new UserRepository;