/* jshint indent: 2 */
var app     = require('../../../app');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];

module.exports = function(sequelize, DataTypes) {
    const UserRoles = sequelize.define('UserRole', {
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        field: 'UserId'
        },
     roleId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      field: 'RoleId'
    }
  }, {
    tableName: 'UserRole',
    timestamps: false,
    freezeTableName: true
  });

    UserRoles.sync().then(() => {
    }).then(() => {
        UserRoles.findAll().then(f => {
            console.log('UserRoles model initiated...');
        });
    });

    UserRoles.associate = (models) => {};
    return UserRoles;
};
