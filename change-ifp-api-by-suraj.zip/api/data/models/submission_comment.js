/* jshint indent: 2 */
var app     = require('../../../app');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];

module.exports = function(sequelize, DataTypes) {
    const SubmissionComments = sequelize.define('SubmissionComment', {
    commentId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'CommentId'
    },
    submissionId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'SubmissionId'
      },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'UserId'
      },
    subject: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'Subject',
        validate: {
          notEmpty: true,
          len: [1,255]
        }
      },
      comment: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: 'Comment',
        validate: {
          notEmpty: true,
          len: [1,65532]
        }
      }
  }, {
    tableName: 'SubmissionComment',
    timestamps: false,
    freezeTableName: true
  });

    SubmissionComments.sync().then(() => {
    }).then(() => {
        SubmissionComments.findAll().then(f => {
            console.log('SubmissionComments model initiated...');
            // Data Seeding
            if(f.length < 1 &&
                config.dialect.toLowerCase()=='mysql' && config.data_seed){
                SubmissionComments.bulkCreate([{submissionId:1, userId:21, subject:'This is a comment for testing', comment:'Just some random text the quick brown fox jumps over the lazy dog'}, 
                                               {submissionId:1, userId:21, subject:'Second comment for testing', comment:'Some more random text the quick brown fox jumps over the lazy dog'}])
                    .then(function(d){console.log('SubmissionComments seeded');})
                    .catch(function(e){console.log('SubmissionComments seed exception',e);});
            }
        });
    });

    SubmissionComments.associate = (models) => {};
    return SubmissionComments;
};
