/* jshint indent: 2 */
var app     = require('../../../app');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];

module.exports = function(sequelize, DataTypes) {
    const ServiceCenters = sequelize.define('ServiceCenter', {
    serviceCenterId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'ServiceCenterId'
    },
    serviceCenter: {
      type: DataTypes.CHAR,
      allowNull: false,
      field: 'ServiceCenter'
    },
    description: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'Description',
      validate: {
        notEmpty: true,
        len: [1,255]
      }
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'Email',
      validate: {
        notEmpty: true,
        len: [1,255]
      }
    }
  }, {
    tableName: 'ServiceCenter',
    timestamps: false,
    freezeTableName: true
  });

    ServiceCenters.sync().then(() => {
    }).then(() => {
        ServiceCenters.findAll().then(f => {
            console.log('ServiceCenters model initiated...');
            // Data Seeding
            if(f.length < 1 &&
                config.dialect.toLowerCase()=='mysql' && config.data_seed){
                ServiceCenters.bulkCreate([{serviceCenter:'C', description:'Central Service Center', email:'central@nodomain.com'}, 
                                           {serviceCenter:'E', description:'Eastern Service Center', email:'eastern@nodomain.com'},
                                           {serviceCenter:'W', description:'Western Service Center', email:'western@nodomain.com'}])
                    .then(function(d){console.log('ServiceCenters seeded');})
                    .catch(function(e){console.log('ServiceCenters seed exception',e);});
            }
        });
    });

    ServiceCenters.associate = (models) => {};
    return ServiceCenters;
};
