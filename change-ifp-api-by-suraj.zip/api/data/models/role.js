/* jshint indent: 2 */
var app     = require('../../../app');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];

module.exports = function(sequelize, DataTypes) {
    const Roles = sequelize.define('Role', {
    roleId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'RoleId'
    },
    role: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'Role',
      validate: {
        notEmpty: true,
        len: [1,255]
      }
    }
  }, {
    tableName: 'Role',
    timestamps: false,
    freezeTableName: true
  });

    Roles.sync().then(() => {
    }).then(() => {
        Roles.findAll().then(f => {
            console.log('Roles model initiated...');
            // Data Seeding
            if(f.length < 1 &&
                config.dialect.toLowerCase()=='mysql' && config.data_seed){
                Roles.bulkCreate([{role:'Authenticated User'}, {role:'Procedure Designer'},{role:'Airport Contact'}, {role:'Environmental Specialist'}, {role:'Service Center Manager'},{role:'Portal Administrator'}])
                    .then(function(d){console.log('Roles seeded');})
                    .catch(function(e){console.log('Roles seed exception',e);});
            }
        });
    });

    Roles.associate = (models) => {};
    return Roles;
};
