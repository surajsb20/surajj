var db          = {};
var log         = require('../../helpers/logger');
//var models      = require('../models');
//var app         = require('../../../app');

const fs        = require('fs');
const path      = require('path');
const Sequelize = require('sequelize');
const basename  = path.basename(module.filename);
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];
const passw     = process.env.DB_PASS || config.password || '';

let sequelize;

  if (config.use_env_variable) {
    sequelize = new Sequelize(process.env[config.use_env_variable]);
  } else {
    console.log("connecting using local config");
    sequelize = new Sequelize(
      config.database, config.username, passw, config
    );
  }


  sequelize
  .authenticate()
  .then(() => {
    console.log('Connection has been established successfully.');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
    sequelize.query("CREATE DATABASE IF NOT EXISTS `"+ config.database + "`;").then(myTableRows => {
      console.log(myTableRows);
    })
  });






fs
  .readdirSync(__dirname)
  .filter((file) =>
    (file.indexOf('.') !== 0) &&
    (file !== basename) &&
    (file.slice(-3) === '.js'))
  .forEach((file) => {
    const model = sequelize.import(path.join(__dirname, file));
    db[model.name] = model;
  });

Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});
log.info('Data Seed is set to ',config.data_seed);

db.sequelize = sequelize;
db.Sequelize = Sequelize;


module.exports = db;