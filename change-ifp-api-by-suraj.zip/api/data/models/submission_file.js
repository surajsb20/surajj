/* jshint indent: 2 */
var app     = require('../../../app');
var fs      = require('fs');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];
const path = require("path");

module.exports = function(sequelize, DataTypes) {
    const SubmissionFiles = sequelize.define('SubmissionFile', {
    fileId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'FileId'
    },
    submissionId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'SubmissionId'
      },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'UserId'
      },
    fileName: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'FileName',
        validate: {
          notEmpty: true,
          len: [1,255]
        }
      },
      file: {
        type: DataTypes.BLOB('medium'),
        allowNull: false,
        field: 'File'
      }
  }, {
    tableName: 'SubmissionFile',
    timestamps: false,
    freezeTableName: true
  });

    SubmissionFiles.sync().then(() => {
    }).then(() => {
        SubmissionFiles.findAll().then(f => {
            console.log('SubmissionFiles model initiated...');
            // Data Seeding
            if (f.length < 1 &&
                config.dialect.toLowerCase()=='mysql' && config.data_seed)
            {
                var blobfile1 = fs.readFileSync(path.resolve(__dirname, '../../assets/img/icon.png'));
                var blobfile2 = fs.readFileSync(path.resolve(__dirname, '../../assets/sample.txt'));

                SubmissionFiles.create({submissionId:1, userId:21, fileName:'icon.png', file:blobfile1})
                    .then(function(d){console.log('SubmissionFile 1 seeded');})
                    .catch(function(e){console.log('SubmissionFile 1 seed exception', e);});
                    
                SubmissionFiles.create({submissionId:1, userId:22, fileName:'textfile.txt', file:blobfile2})
                    .then(function(d){console.log('SubmissionFile 2 seeded');})
                    .catch(function(e){console.log('SubmissionFile 2 seed exception', e);});
            }
        });
    });

    SubmissionFiles.associate = (models) => {};
    return SubmissionFiles;
};
