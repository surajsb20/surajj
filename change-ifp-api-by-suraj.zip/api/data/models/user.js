/* jshint indent: 2 */
//var app     = require('../../../app');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];
const bcrypt = require('bcrypt');

module.exports = function(sequelize, DataTypes) {
    const Users = sequelize.define('User', {
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'UserId'
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'FirstName',
      validate: {
        notEmpty: true,
        len: [1,255]
      }
    },
    lastName: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'LastName',
      validate: {
        notEmpty: true,
        len: [1,255]
      }
    },
    passwordHash: {
      type: DataTypes.STRING,
      //allowNull: false,
      field: 'PasswordHash'
    },
    password: {
      type: DataTypes.VIRTUAL,
      allowNull: false,
      validate: {
        notEmpty: true,
        isLongEnough: function (val) {
          if (val.length < 6) 
            throw new Error("Please choose a longer password");
         }
      }
    },
    password_confirmation: {
      type: DataTypes.VIRTUAL
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unqiue: true,
      field: 'Email',
      validate: {
        isEmail: true,
        notEmpty: true,
        len: [1,255]
      }
    },
    airportId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      field: 'AirportId'
    },
    serviceCenterId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      field: 'ServiceCenterId'
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
      field: 'IsActive'
    }
  },
   {
    tableName: 'User',
    timestamps: false,
    freezeTableName: true,
    indexes: [{unique: true, fields: ['email']}],
	  instanceMethods: {
		  authenticate: function(value) {
			  if (bcrypt.compareSync(value, this.passwordHash))
				  return this;
			  else 
				  return false;
		  }
	  }
  });


  
  /*function cryptPassword(password, callback) 
  {
    bcrypt.genSalt(10, function(err, salt) { // Encrypt password using bycrpt module
        if (err)
            return callback(err);

        bcrypt.hash(password, salt, function(err, hash) {
            return callback(err, hash);
        });
    });
  }*/

  Users.beforeCreate((user, options) => {

    return bcrypt.hash(user.password, 10)
        .then(hash => {
            user.passwordHash = hash;
        })
        .catch(err => { 
            throw new Error(); 
        });
  });

  Users.beforeUpdate((user, options) => {
    return bcrypt.hash(user.password, 10)
        .then(hash => {
            user.passwordHash = hash;
        })
        .catch(err => { 
            throw new Error(); 
        });
  });

  Users.sync().then(() => {
    }).then(() => {
        Users.findAll().then(f => {
            console.log('Users model initiated...');
            // Data Seeding
            if (f.length < 2 && config.dialect.toLowerCase()=='mysql' && config.data_seed)
            {
                Users.create({firstName:'admin', lastName:'admin', password:'admin123', email:'admin@gmail.com', isActive:true})
                    .then(function(d){console.log('Admin Role seeded');})
                    .catch(function(e){console.log('User 1 seed exception',e);});               
            }
        });
    });

    Users.associate = (models) => {};
    return Users;
};
