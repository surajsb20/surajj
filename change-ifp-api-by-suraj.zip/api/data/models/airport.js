/* jshint indent: 2 */

var app     = require('../../../app');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];


module.exports = function(sequelize, DataTypes) {
    const Facilities = sequelize.define('Airport', {
    airportId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'AirportID'
    },
    facilityName: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'FacilityName'
    },
    airportType: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'AirportType'
    },
    aptCode: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'AptCode'
    },
    faaCode: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'FaaCode'
    },
    icaoCode: {
      type: DataTypes.STRING,
      allowNull: true,
      field: 'IcaoCode'
    },
    region: {
      type: DataTypes.STRING,
      allowNull: true,
      field: 'Region'
    },
    state: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'State'
    },
    siteName: {
      type: DataTypes.STRING,
      allowNull: true,
      field: 'SiteName'
    },
    latitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'Latitude'
    },
    longitude: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'Longitude'
    },
    elevation: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'Elevation'
    },
    serviceCenter: {
      type: DataTypes.CHAR,
      allowNull: false,
      field: 'ServiceCenter'
    },
    siteNumber: {
      type: DataTypes.STRING,
      allowNull: true,
      field: 'SiteNumber'
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
      field: 'IsActive'
    }
  }, {
    tableName: 'Airport',
    timestamps: false,
    freezeTableName: true
  });

    Facilities.sync().then(() => {
    }).then(() => {
        Facilities.findAll().then(f => {
            console.log('Airports model initiated...');

            // Data Seeding
            if (f.length < 2 &&
                config.dialect.toLowerCase()=='mysql' && config.data_seed){
                Facilities.bulkCreate([{facilityName:'Atlanta International Airport', airportType:'AIRPORT', aptCode:'KATL', faaCode:'ATL', icaoCode:'KATL', region:'Eastern', state:'GA', siteName:'atlSite', latitude:33.6366996, longitude:-84.4278640, elevation:1026, serviceCenter:'E', isActive:true}, 
                                       {facilityName:'Missoula Domestic Airport', airportType:'AIRPORT', aptCode:'KMSO', faaCode:'MSO', icaoCode:'KMSO', region:'Western', state:'MT', siteName:'msoSite', latitude:46.9163056, longitude:-114.0905556, elevation:3205, serviceCenter:'W', isActive:true}])
                    .then(function(d){console.log('Facilities seeded');})
                    .catch(function(e){console.log('Facilities seed exception',e);});
            }
        });
    });

  Facilities.associate = (models) => {};
  return Facilities;
};
