/* jshint indent: 2 */
var app     = require('../../../app');
const env       = process.env.NODE_ENV || 'development_mysql';
const config    = require('../../../config/config.json')[env];

module.exports = function(sequelize, DataTypes) {
    const Submissions = sequelize.define('Submission', {
    submissionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
      field: 'SubmissionId'
    },
    requestId: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'RequestId',
      validate: {
        notEmpty: true,
        len: [1,255]
      }
    }, 
    airportId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'AirportId'
      },
    airportCode: {
      type: DataTypes.STRING,
      allowNull: false,
      field: 'AirportCode',
      validate: {
        notEmpty: true,
        len: [1,4]
      }
    },
    workflowState: {
        type: DataTypes.ENUM('IFP', 'Airport', 'Service Center', 'Closed'),
        allowNull: false,
        field: 'WorkflowState',
        defaultValue: 'IFP',
        validate: {
          notEmpty: true,
          len: [1,16]
        }
      },
    serviceCenterId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'ServiceCenterId'
      },
    procedureDesignerId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'ProcedureDesignerId'
      },
    publicationDate: {
        type: DataTypes.DATE,
        allowNull: false,
        field: 'PublicationDate'
      },
    airportContactId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'AirportContactId'
      },
    airportContactEmail: {
      type: DataTypes.STRING,
      allowNull: true,
      unique: true,
      field: 'AirportContactEmail',
      validate: {
        isEmail: true,
        notEmpty: false,
        len: [1,255]
      }
    },
    procedureRequestType: {
        type: DataTypes.ENUM('New', 'Amended'),
        allowNull: false,
        field: 'ProcedureRequestType',
        defaultValue: 'New',
        validate: {
          notEmpty: true,
          len: [1,8]
        }
      },
    isSingle: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true,
        field: 'IsSingle'
      },
    procedureName: {
        type: DataTypes.STRING,
        allowNull: false,
        field: 'ProcedureName',
        validate: {
          notEmpty: true,
          len: [1,255]
        }
      },
    procedureDescription: {
        type: DataTypes.TEXT,
        allowNull: false,
        field: 'ProcedureDescription',
        validate: {
          notEmpty: true,
          len: [1,65532]
        }
      },
    procedureBenefit: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'ProcedureBenefit',
        validate: {
          len: [0,65532]
        }
      },
     procedureNeed: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'ProcedureNeed',
        validate: {
          len: [0,65532]
        }
      },
    isConsensusFormAttached: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsConsensusFormAttached'
      },
    isChangeLinesOfMinimum: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsChangeLinesOfMinimum'
      },
    isAltitudeIncreases: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsAltitudeIncreases'
      },
    isIfrTakeoffAndDPs: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsIfrTakeoffAndDPs'
      },
    isMinimumSafeAltitude: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsMinimumSafeAltitude'
      },
    isChangeToCircling: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsChangeToCircling'
      },
    isArrivalHolding: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsArrivalHolding'
      },
    isConsensusFormAttached: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsConsensusFormAttached'
      },
    isVisualClimbOverAirport: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsVisualClimbOverAirport'
      },
    isMissedApproaches: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsMissedApproaches'
      },
    isNameChanges: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsNameChanges'
      },
    isAmendingNotes: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsAmendingNotes'
      },
    isMagneticVariationAdjustments: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsMagneticVariationAdjustments'
      },
    isCodingChanges: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCodingChanges'
      },
    isConsensusFormAttached: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsConsensusFormAttached'
      },
    isCodingChanges: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCodingChanges'
      },
    isCancellationIFPs: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCancellationIFPs'
      },
    isOnlyChangesToProcedure: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsOnlyChangesToProcedure'
      },
    isApproachProcedure: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsApproachProcedure'
      },
    isDepartureProcedure: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsDepartureProcedure'
      },
    isEnrouteProcedure: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsEnrouteProcedure'
      },
    isOnlyHelicopterOps: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsOnlyHelicopterOps'
      },
    isEmergencyHeloRoute: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsEmergencyHeloRoute'
      },
    procedureAltitude: {
        type: DataTypes.ENUM('Surface to 3,000 feet AGL', '3,0001 to 7,000 feet AGL', '7,0001 to 10,000 feet AGL', '10,0001 to 18,000 feet AGL', 'Above 18,000 feet AGL'),
        allowNull: false,
        field: 'ProcedureAltitude',
        defaultValue: 'Surface to 3,000 feet AGL',
        validate: {
          notEmpty: true,
          len: [1,255]
        }
      },
    isTrackKmlAttached: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsTrackKmlAttached'
      },
    trackCoordinateInput: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'TrackCoordinateInput',
        validate: {
          len: [0,65532]
        }
      }, 
    numHelicopterDayOps: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'NumHelicopterDayOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
    numHelicopterEveningOps: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'NumHelicopterEveningOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
    numHelicopterNightOps: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'NumHelicopterNightOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
    numPropsDayOps: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'NumPropsDayOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
    numPropsEveningOps: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'NumPropsEveningOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
     numPropsNightOps: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'NumPropsNightOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
    numJetsDayOps: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'NumJetsDayOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
    numJetsEveningOps: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'NumJetsEveningOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
     numJetsNightOps: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'NumJetsNightOps',
        defaultValue: 0,
        validate: { min: 0, max: 1000000 }
      },
    isResidential: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsResidential'
      },
    isEducational: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsEducational'
      },
    isHospital: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsHospital'
      },
    isReligiousStructure: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsReligiousStructure'
      },
    isRecreational: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsRecreational'
      },
    isCulturalSites: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCulturalSites'
      },
    isParkNotNational: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsParkNotNational'
      },
    isWildernessNotNational: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsWildernessNotNational'
      },
    isWildlifeNotNational: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsWildlifeNotNational'
      },
    isNationalPark: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsNationalPark'
      },
    isNationalWilderness: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsNationalWilderness'
      },
    isNationalWildlifeRefuge: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsNationalWildlifeRefuge'
      },
    isUnknown: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsUnknown'
      },
    isNone: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsNone'
      },
    airportContactNotes: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'airportContactNotes',
        validate: {
          len: [0,65532]
        }
      }, 
    environmentalSpecialistId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        field: 'EnvironmentalSpecialistId'
      },
    historicProperties: {
        type: DataTypes.ENUM('None', 'Waiting for SHPO Response', 'Historic Properties Impacted', 'No Historic Properties Impacted', 'Letter Has Been Sent'),
        allowNull: false,
        field: 'HistoricProperties',
        defaultValue: 'None',
        validate: {
          notEmpty: true,
          len: [1,48]
        }
      },
    shpoLetterDateSent: {
        type: DataTypes.DATE,
        allowNull: true,
        field: 'ShpoLetterDateSent'
      },
    procedureDescriptionForCATEX: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'ProcedureDescriptionForCATEX',
        validate: {
          len: [0,65532]
        }
      },
    environmentalSpecialistNotes: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'EnvironmentalSpecialistNotes',
        validate: {
          len: [0,65532]
        }
      },
    FilterToolRecommendation: {
        type: DataTypes.TEXT,
        allowNull: true,
        field: 'FilterToolRecommendation',
        validate: {
          len: [0,65532]
        }
      },
    isCatexEligible: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: false,
        field: 'IsCatexEligible'
      },
    isCATEX_h: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCATEX_h'
      },
    isCATEX_i: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCATEX_i'
      },
    isCATEX_j: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCATEX_j'
      },
    isCATEX_k: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCATEX_k'
      },
    isCATEX_p: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCATEX_p'
      },
      isCATEX_VorMon: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        field: 'IsCATEX_VorMon'
      }
  },
   {
    tableName: 'Submission',
    timestamps: false,
    freezeTableName: true,
    indexes: [{unique: true, fields: ['requestId']}]
  });



    Submissions.sync().then(() => {
    }).then(() => {
        Submissions.findAll().then(f => {
            console.log('Submissions model initiated...');
            // Data Seeding
            if (f.length < 1 && config.dialect.toLowerCase()=='mysql' && config.data_seed)
            {
                Submissions.create({requestId:'ORD_180809_01', airportCode:'KORD', workflowState:'IFP', 
                                    procedureDesignerId:21, publicationDate:Date.now(), procedureRequestType:'New',
                                    isSingle:true, procedureName:'My New Procedure', procedureDescription:'A description for the new procedure',
                                    procedureAltitude:'3,0001 to 7,000 feet AGL'})
                    .then(function(d){console.log('Submission 1 seeded');})
                    .catch(function(e){console.log('Submission 1 seed exception',e);});
            }
        });
    });

    Submissions.associate = (models) => {};
    return Submissions;
};
