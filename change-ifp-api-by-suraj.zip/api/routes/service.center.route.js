const Route = require('express').Router();
const serviceCenterController = require('../controllers/service.center.controller');
Route.get('/', serviceCenterController.list);
Route.get('/:id', serviceCenterController.details);
Route.post('/', serviceCenterController.create);
Route.put('/:id', serviceCenterController.update);
Route.delete('/:id', serviceCenterController.destroy);
module.exports = Route;