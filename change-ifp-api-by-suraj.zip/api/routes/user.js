const Route = require('express').Router();
const aclController = require('../controllers/acl.controller');
const userController = require("../controllers/user.controller");
Route.post('/role/assign', aclController.assignRoleToUser);
Route.put('/:userId/roles/remove', aclController.destroyUserRoles);
Route.get('/:userId/roles', aclController.getRolesByUser);
Route.get('/:userId/role/:roleName', aclController.hasRole);
Route.post('/signup', userController.signup);
Route.post('/login', userController.login); 

module.exports = Route;