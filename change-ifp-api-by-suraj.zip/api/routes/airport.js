const Route = require('express').Router();
const airportController = require('../controllers/airport.controller');
Route.get('/', airportController.allAirports);
Route.post('/', airportController.createAirport);
Route.get('/:id', airportController.airportById);
Route.put('/:id', airportController.updateAirport);
Route.delete('/:id', airportController.destroyAirport);
module.exports = Route;