const Route = require('express').Router();
const multer  = require('multer')
var storage = multer.memoryStorage(/* {
    destination: (req, file, cb) => {
      cb(null, 'uploads')
    },
    filename: (req, file, cb) => {
        console.log(file, "file details");
        var ext = file.originalname.substr(file.originalname.lastIndexOf('.') + 1);
        var newFileName = Date.now() +'.'+ ext;
        cb(null,newFileName)
    }
} */);
var upload = multer({ storage: storage })
const submissionFileController = require('../controllers/submission.file.controller');
Route.post('/:id',upload.single('file'),  submissionFileController.uploadFile);
Route.get('/:id', submissionFileController.listSubmissionFiles);

module.exports = Route;