const Route = require('express').Router();
const submissionController = require('../controllers/submission.controller');
Route.get('/', submissionController.list);
Route.get('/:id', submissionController.details);
Route.post('/', submissionController.add);
Route.put('/:id', submissionController.update);
Route.delete('/:id', submissionController.destroy);
module.exports = Route;