const Route = require('express').Router();
const aclController = require('../controllers/acl.controller');
Route.post('/', aclController.createRole);
Route.delete('/:roleName', aclController.destroyRole);
Route.get('/:roleName/permissions', aclController.getPermissionsByRole);
module.exports = Route;
