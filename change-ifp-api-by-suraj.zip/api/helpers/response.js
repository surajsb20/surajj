var fs              = require('fs');
var instantiator    = require('json-schema-instantiator');
var contents        = fs.readFileSync('api/schema/schema-2.json', 'utf8');
var schema          = JSON.parse(contents);
var log             = require('./logger');
var jwtHelper       = require('./jwtHelper');

class Response {
    constructor() {
        this.instance = instantiator.instantiate(schema);
        this.instance.apiVersion = "1.0.0";
    }
}

module.exports = Response;