const RESPONSE_CODES = new Object();

RESPONSE_CODES['NO_HEADERS_FOUND']         =    {code:400, message:'No Headers Found'};
RESPONSE_CODES['NO_AUTHORIZATION_HEADERS_FOUND']         =    {code:400, message:'No Authorization Headers Found'};
RESPONSE_CODES['NO_EMAIL_FOUND']           =    {code:400, message:'No Email Found'};
RESPONSE_CODES['INVALID_TOKEN']            =    {code:400, message:'Invalid Token'};
RESPONSE_CODES['TOKEN_EXPIRED']            =    {code:400, message:'Token Expired'};
RESPONSE_CODES['CANNOT_DECODE_TOKEN']      =    {code:400, message:'Cannot Decode the Token'};

module.exports = RESPONSE_CODES;