var winston = require('winston');
var moment  = require('moment');

var log = new (winston.Logger)({
    transports: [
      new (winston.transports.Console)({
          timestamp() {
              return moment().format('YYYY-MM-DD HH:mm:ss.SSSS');
          }
      }),
      new (winston.transports.File)({ filename: 'node-toolkit.log' })
    ]
  });

module.exports = log;