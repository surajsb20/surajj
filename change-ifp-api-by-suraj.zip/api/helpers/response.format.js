module.exports = {
    success : success,
    error: error
}


function success(data = null, message = null){
    return {
        "status" : "success",
        "data" : data,
        "message": message
    }
}


function error(data = null, message = null){
    return {
        "status" : "error",
        "data" : data,
        "message": message
    }
}