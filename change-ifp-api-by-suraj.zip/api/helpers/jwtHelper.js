var log         = require('./logger');
var jwt         = require('jsonwebtoken');
var app         = require('../../app');
const env       = process.env.NODE_ENV || 'development_sqlite';
const config    = require('../../config/config.json')[env];
const RESPONSE_CODES= require('./responseCodes');

module.exports = {

    isValidToken(token) {
        log.info('Verify initiated. Carrying token?', token?true:false);
        return new Promise(function(fulfill,reject){
            jwt.verify(token, config.jwt_secret, function (err, d) {
                log.info(err?'Invalid Token':'Valid Token. Proceeding Request.');
                if (err) {reject(RESPONSE_CODES['INVALID_TOKEN']);}
                else {fulfill(d);}
            });
        });
    },

    decodeToken(token){
        var decoded = {};
        decoded = jwt.decode(token,{complete:true});
        return decoded;
    },

    generateToken(email){

    }
};