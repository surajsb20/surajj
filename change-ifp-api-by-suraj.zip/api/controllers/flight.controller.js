'use strict';

var flightResponse    = require('../helpers/response.js');
var service     = require('../services/flight.service');
var log         = require('../helpers/logger');
var util        = require('util');
var models      = require('../data/models');
var token_f         = require('../helpers/jwtHelper');
module.exports = {
    createAirport       : create,
    getFlights          : getAll,
    getFlightById       : getById,
    updateFlight        : update,
    destroyFlight       : destroy
};

/*
  Param 1: a handle to the request object
  Param 2: a handle to the response object
 */
function getAll(req, res) {
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('getAll initiated...');
    let response = new flightResponse;
    service.all()
        .then(function(f){
            response.instance.data.items.push(f);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        })
}
}
function create(req, res) {
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('createFlight initiated...');
    var flightReq = req.swagger.params.flight.value;
    let response = new flightResponse;
    service.create(flightReq)
        .then(function(d){
            response.instance.data.items.push(d);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}

function getById(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('getByName initiated...');
    var request = req.swagger.params;
    let response = new flightResponse;
    service.byId(request.id.value)
        .then(function(f){
            response.instance.data.items.push(f);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}

function update(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('update initiated...');
    let request = req.swagger.params.flight.value;
    let flightId = req.swagger.params.id.value;
    let response = new flightResponse;
    service.update(flightId, request)
        .then(function(f){
            response.instance.data.items.push(f);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}

function destroy(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('destroy initiated...');
    let id = req.swagger.params.id.value;
    let response = new flightResponse;
    service.delete(id)
        .then(function(f){
            response.instance.data.items.push(f);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        })
}}