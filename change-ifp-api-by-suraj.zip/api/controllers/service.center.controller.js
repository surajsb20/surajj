const Models = require('../data/models');
var Response    = require('../helpers/response.js');
var log         = require('../helpers/logger');

var token_f         = require('../helpers/jwtHelper');
module.exports = {
    list: list,
    create:create,
    destroy: destroy,
    details : details,
    update: update
}

function list(req, res){
     const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('service center list api called...');
    let response = new Response();
    Models.ServiceCenter.findAll().then((centers)=>{
        if(!centers || centers.length==0){
            res.json(response.instance);
        } else {
            response.instance.data.items = centers;
            res.json(response.instance);                
        }
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });
}
}
function details(req, res){
     const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('service center details api called...');
    let response = new Response();
    Models.ServiceCenter.findAll({where: {serviceCenterId : req.params.id}})
    .then((center)=>{
        if(!center || center.length==0){
            res.json(response.instance);
        } else {
            response.instance.data.items = center;
            res.json(response.instance);                
        }
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });}
}

function create(req, res) {
    log.info('create service center initiated...');
    let response = new Response();
     const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    Models.ServiceCenter.create(req.body)
        .then(function(data){
            response.data.items.push(data);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}

function update(req, res) {
     const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('update service center initiated...', req.params.id);
    let request = req.body;
    let serviceCenterId = req.params.id;
    let response = new Response();
    Models.ServiceCenter.update(request, {where:{serviceCenterId: serviceCenterId}})
        .then(function(d){
            response.data.items.push(d);
            res.json(response);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}

function destroy(req, res) {
     const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('destroy initiated...');
    let id = req.params.id;
    let response = new Response();
    Models.ServiceCenter.destroy({where: {serviceCenterId:id}})
        .then(function(d){
            response.instance.data.items.push(d);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}