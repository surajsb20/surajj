'use strict';
var Response    = require('../helpers/response.js');
var service     = require('../services/airport.service');
var log         = require('../helpers/logger');
var util        = require('util');
const Models    = require('../data/models');
var token_f         = require('../helpers/jwtHelper');
module.exports = {
    allAirports     :all,
    airportById     :byId,
    createAirport   :create,
    updateAirport   :update,
    destroyAirport  :destroy
};

/*
  Functions in a127 controllers used for operations should take two parameters:

  Param 1: a handle to the request object
  Param 2: a handle to the response object
 */
function all(req, res) {
    // variables defined in the Swagger document can be referenced using req.swagger.params.{parameter_name}
const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('all initiated...');
    let response = new Response();
 
    Models.Airport.findAll()
        .then(function(data){            
            if(!data || data.length==0){
                res.json(response.instance);
            } else {
                response.instance.data.items = data;
                res.json(response.instance);                
            }
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}
}
function byId(req, res) {
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('byId initiated...');
    var airportId = req.params.id;
    let response = new Response();
    Models.Airport.findAll({where: {
        airportId: airportId
      }})
    .then(function(data){
        if(!data || data.length==0){
            res.json(response.instance);
        } else {
            response.instance.data.items = data;
            res.json(response.instance);
        }
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });
}
}
function create(req, res) {
    
    log.info('create initiated...');
    let response = new Response();
  const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    Models.Airport.create(req.body)
        .then((airportRes)=>{
            response.instance.data.items = airportRes;
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });}
}

function update(req, res) {
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('update initiated...', req.params.id);
    let request = req.body;
    let airportId = req.params.id;
    let response = new Response();
    Models.Airport.update(request, {where:{airportId: airportId}})
        .then(function(d){            
            response.instance.data.items = d;
            res.json(response);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}
}
function destroy(req, res) {
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('destroy initiated...');
    let id = req.params.id;
    let response = new Response();
    Models.Airport.destroy({where: {airportId:id}})
        .then(function(d){
            response.instance.data.items = d;
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}
}