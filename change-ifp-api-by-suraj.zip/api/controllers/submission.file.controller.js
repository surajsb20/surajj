const Models    = require('../data/models');
const Response    = require('../helpers/response.js');
const log         = require('../helpers/logger');
var token_f         = require('../helpers/jwtHelper');


module.exports = {
    uploadFile : uploadFile,
    listSubmissionFiles : listSubmissionFiles
}

function uploadFile(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    let body = req.body;
    var ext = req.file.originalname.substr(req.file.originalname.lastIndexOf('.') + 1);
    var newFileName = Date.now() +'.'+ ext;
    let NewSubmissionFile = {
        submissionId : req.params.id,
        userId : body.userId,
        fileName : newFileName,
        file : req.file.buffer
    }
    let response = new Response();
    Models.SubmissionFile.create(NewSubmissionFile)
    .then(function(data){
        response.data.items.push(data);
        res.json(response.instance);
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });}
}

function listSubmissionFiles(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    let submissionId = req.params.id;
    let response = new Response();
    Models.SubmissionFile.findAll({attributes: ['SubmissionId'], where : {submissionId: submissionId}})
    .then(function(data){
        response.data.items = data;
        res.json(response);
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });}
}