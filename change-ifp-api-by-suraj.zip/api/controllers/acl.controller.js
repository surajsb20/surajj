'use strict';

var authorityResponse    = require('../helpers/response.js');
//var service     = require('../services/airport.service');
var log         = require('../helpers/logger');
//var util        = require('util');
var Acl         = require('acl');
//var Sequelize   = require('sequelize');
var AclSeq      = require('acl-sequelize');
var db        = require('../data/models/index');
var acl         = new Acl(new AclSeq(db.sequelize, {prefix:'acl_'},{sync: true}));

module.exports = {
    createRole          :createRole,
    getPermissionsByRole:getPermissionsByRole,
    destroyRole         :removeRole,
    assignRoleToUser    :assignRoleToUser,
    getRolesByUser      :getRolesByUser,
    destroyUserRoles    :removeUserRoles,
    hasRole             :hasRole
};

/*
  Functions in a127 controllers used for operations should take two parameters:

  Param 1: a handle to the request object
  Param 2: a handle to the response object
 */
function createRole(req, res) {
    
    log.info('create initiated...-');
    let request = req.body;
    let response = new authorityResponse();

    acl.allow(request.roles,request.resources,request.permissions,
        function(e){
            if(e){
                log.error('Exception while creating authorities',e);
                response.instance.error.message=e;
                res.json(response.instance);
            } else {
                acl.whatResources(request.roles,
                    function(e,r){
                        if(e){response.instance.error.message.push(e); res.json(response.instance);}
                        else{
                            if(!r || r.length==0){res.json(response.instance);}
                            else {
                                Object.keys(r).map(function(a,p){
                                    response.instance.data.items.push({'role':request.roles,'resources':a,'permissions':r[a]});
                                    if(response.instance.data.items.length==Object.keys(r).length){
                                        res.json(response.instance);
                                    }
                                });
                            }
                        }
                    });
            }
        });
}

function getPermissionsByRole(req, res){

    log.info('allByRoles initiated...');
    let response = new authorityResponse();
    let roleName = req.params.roleName;
    log.info('*',JSON.stringify(roleName));
    acl.whatResources(roleName,
        function(e,r){
            if(e){response.instance.error.message.push(e); res.json(response.instance);}
            else{
                if(!r || Object.keys(r).length==0){res.json(response.instance);}
                else {
                    Object.keys(r).map(function(a,p){
                        response.instance.data.items.push({'role':roleName,'resources':a,'permissions':r[a]});
                        if(response.instance.data.items.length==Object.keys(r).length){
                            res.json(response.instance);
                        }
                    });
                }
            }
        });
}

function removeRole(req, res){
    log.info('removeRole initiated...');
    let response = new authorityResponse();
    let roleName = req.params.roleName;
    acl.removeRole(roleName,
        function(e){
            if(e){response.instance.error.massage.push(e);res.json(response.instance);}
            else{res.json(response.instance);}
        });
}

function assignRoleToUser(req, res){
    log.info('assignRoleToUser initiated...');
    let response = new authorityResponse();
    let request = req.body;
    log.info('REQ--', JSON.stringify(request));
    let userId = request.userId;
    let roles = request.roles;
    acl.addUserRoles(userId, roles,
        function(e){
            if(e){response.instance.error.message.push(e);res.json(response.instance);}
            else {
                acl.userRoles(userId,
                    function(e,r){
                        if(e){response.instanc.error.message.push(e);res.json(response.instance);}
                        else{response.instance.data.items.push(r);res.json(response.instance);}
                    });
            }
        });
}

function getRolesByUser(req, res){
    log.info('getRolesByUser...');
    let response = new authorityResponse();
    let userId = req.params.userId;
    acl.userRoles(userId,
        function(e,r){
            if(e){response.instanc.error.message.push(e);res.json(response.instance);}
            else{response.instance.data.items.push(r);res.json(response.instance);}
        });
}

function removeUserRoles(req, res){
    log.info('removeUserRoles initiated...');
    let response = new authorityResponse();
    let roles  = req.body.roles;
    let userId   = req.params.userId;
    acl.removeUserRoles(userId, roles,
        function(e){
            if(e){response.instance.error.message.push(e);res.json(response.instance);}
            else{res.json(response.instance);}
        });
}

function hasRole(req, res){
    log.info('hasRole initiated...-');
    let response = new authorityResponse();
    let roleName = req.params.roleName;
    let userId = req.params.userId;
    acl.hasRole(userId, roleName,
        function(e,r){
            if(e){response.instance.error.message.push(e);res.json(response.instance);}
            else{response.instance.data.items.push(r); res.json(response.instance);}
        });
}