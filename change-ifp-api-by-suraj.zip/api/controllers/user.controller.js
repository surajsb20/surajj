const Models = require('../data/models');
const bcrypt = require('bcrypt');
const env           = process.env.NODE_ENV || 'development_mysql';
const envConfig     = require(`${__dirname}/../../config/config.json`)[env];
var jwt = require('jsonwebtoken');

module.exports = {
    signup : signup,
    login: login
}

function signup(req, res){
    let newUser = req.body;
  
    Models.User.create(newUser)
    .then((userInfo)=>{
        res.send({message : "Used Saved Successfully", data: userInfo});
    })
    .catch((err)=>{
        console.error(err, "Error in user signup");
        res.status(500).send(err);
    }) 
}

function login(req, res){
    let user = req.body;
    Models.User.find({where: {email : user.email}})
    .then((userInfo)=>{
        if(userInfo){
            let comparePassword = bcrypt.compareSync(user.password, userInfo.passwordHash);
            if(comparePassword) {
                let userData = {
                    userId: userInfo.userId,
                    email : userInfo.email,
                    firstName : userInfo.firstName,
                    lastName: userInfo.lastName
                }
                let  token =    jwt.sign(userData, envConfig.jwt_secret);   
                userData.token = token;  
                console.log(userData.token);
               
                res.send({ status: "success", message:"Used Login Successfully", data:userData });
            }
            else{
                res.status(500).send({status : "error", data : null, message: "Invalid credentials"});
            }
        }
        else{
            res.status(500).send({status : "error", data : null, message: "User not found with given email address"});
        }        
    })
    .catch((err)=>{        
        res.status(401).send(err);
    }) 
}