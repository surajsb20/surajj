'use strict';
const Models    = require('../data/models');
var Response    = require('../helpers/response.js');
var log         = require('../helpers/logger');
const moment    = require('moment');

var token_f         = require('../helpers/jwtHelper');
module.exports = { 
    add     : add,
    list    : list,
    update  : update, 
    destroy : destroy,
    details : details
};

function add(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    let response = new Response();
    let requestCode = req.body.airportId + moment().format("YYDDMM_HIS") ;
    let currentDate = moment();
    let d = req.body;
    d.requestId = requestCode;
    d.publicationDate = currentDate;
    /* let request = {
        requestId : requestCode,
        airportId :  d.airportId,
        airportCode : d.airportCode,
        serviceCenterId : d.serviceCenterId,
        procedureDesignerId : d.procedureDesignerId,
        publicationDate :currentDate,
        procedureName : d.procedureName,
        procedureDescription : d.procedureDescription,
        procedureBenefit : d.procedureBenefit,
        procedureNeed : d.procedureNeed,
        isConsensusFormAttached : d.isConsensusFormAttached         
    } */
    Models.Submission.create(d)
    .then((data)=>{
        response.instance.data.items = data;
        res.json(response.instance);    
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });
}
}
function details(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    Models.Submission.findAll({where:{
        submissionId : req.params.id
    }})
    .then((data)=>{
        response.instance.data = data;
        res.json(response.instance);
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });
}}

function list(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    let response = new Response();
    Models.Submission.findAll()
    .then((data)=>{
        response.instance.data.items = data;
        res.json(response.instance);
    })
    .catch(function(e){
        response.instance.error.message=e;
        res.json(response.instance);
    });
}   
}
function update(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('update initiated...', req.params.id);
    let request = req.body;
    let submissionId = req.params.id;
    let response = new Response();
    Models.Submission.update(request, {where : {submissionId: submissionId}})
        .then(function(d){
            response.data.items.push(d);
            res.json(response);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}

function destroy(req, res){
    const token = req.headers['authorization'];
  const btoken=token.split(' ');
  
  console.log(token_f.decodeToken(btoken[1]));
    if (!token_f.decodeToken(btoken[1])) { //token verfy code
        return res.status(401).send({ auth: false, message: 'No token provided.' });
     }else{
    log.info('destroy initiated...');
    let id = req.params.id;
    let response = new Response();
    Models.Airport.destroy(req.body, {where: {submissionId:id}})
        .then(function(d){
            response.instance.data.items.push(d);
            res.json(response.instance);
        })
        .catch(function(e){
            response.instance.error.message=e;
            res.json(response.instance);
        });
}}