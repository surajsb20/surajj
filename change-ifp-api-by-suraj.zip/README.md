# Node Toolkit
The main purpose of this repository is to provide a good end-to-end starter template for creating a node.js based project that includes the following features:
- RESTful Services
- Database access via ORM framework (Sequelize)
- SAML bridge for authentication
- API documentation using Swagger
- Service Contract

# Pre-reqs
- Install [Node.js](https://nodejs.org/en/)
- Install [VS Code](https://code.visualstudio.com/) (Optional)

## Install dependencies
```
cd <project_name>
Run `npm install` to install needed packages.
## Development server
Run `npm start` for a dev server. Navigate to `http://localhost:10010/docs/`. 
The app will automatically reload if you change any of the source files.
## Running tests
Run `npm test` to execute the tests via [Mocha](https://mochajs.org).
## Build
NOTE: this feature is not ready yet
Run `npm build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.
 
## Toolkit layout
 - `Controllers` - The Swagger configuration delegates the incoming request to the configured controller method. All the CRUD methods in the controller have two parameters. The first param is request and the other one is response. The incoming parameters can be referenced through request *(req.swagger.params.[parameter_name])*. Any request validation must be done in controller and then forward to service for further processing.  
 - `Services` - The request received from Controller is processed by calling methods in Repository layer as needed. The results are formatted here according to the schema as defined (Data massaging happens here).
 - `Repositories` - This consists of various CRUD supporting methods through the database ORM.
 - `Models` - Every Model is defined according to the Sequelize definition. These models are used in Repository to create ORM-supporting methods.
 - `Schemas` - Schema is placed in /api/schema/ and is used as an agreement between the services and the consumers.
 - `Swagger-middleware` - The Swagger configuration is located in /api/swagger/swagger.yaml . This file has all the configurations needed to enable a HTTP service and forward it to a controller method. For better understanding, the default swagger.yaml file is included with all HTTP operations like GET, POST, PATCH, PUT and DELETE. The same config file enables the API documentation that is available at http://localhost:10010/docs/.
 - `Helpers` - This folder is to hold any reusable piece-of-code (methods/functions/variables). Currently, this is being used to initiate the response object and assign metadata such as version.
 - `Tests` - All the test-related code is placed in this folder. The code here is further classified based on its target classes such as controllers, helpers, services.

## Packages used
 - `express` *For web framework*
 - `swagger-express-mw` *For Middleware support for express*
 - `sequelize` *ORM for Node.JS. Supports databases mysql, sqlite, postgres and mssql*
 - `tedious` *For connecting to Microsoft SQL databases*
 - `winston` *For asynchronous logging*
 - `mocha` *For testing framework*
 -  `acl` *For authorization support. Stand for Access Control List*
 -  `acl-sequelize` *For integration between acl and sequelize packages*
  
## Database Configuration
The Node Toolkit 0.0.1 provides the support for Microsoft SQL DB connection by default. Refer to `config/config.json` to provide the DB connection details.
### To add models (and repository)
All the database model definitions are placed in the `api/data/models` along with their corresponding repositories in `api/data/repository`. The definition is strictly in adherence to the `Sequelize` specifications. For information on `Sequelize`, refer to [Sequelize Documentation](https://docs.sequelizejs.com) and their [Github Page](https://github.com/sequelize/sequelize). The `api/data/models/index.js` initiates the `Sequelize` ORM and holds configs needed to map all the models defined in the `api/data/models` with database connected.
### To add controllers (and services)
All the Controllers are placed in `api/controllers` and `api/services` contains all the Services. All the Controller functions have two parameters `req` and `res`. The `req` holds the incoming request params and `res` is the response param to carry the service response. Ideally, all the incoming requests should be validated in the `Controller` function and forward the call to `Service` function. `Promises` are used to ensure the response is calculated and sent back in synchronous manner.
### To add a Path/Route
The Toolkit uses `Swagger Tool's` `Middleware` for route support and API documentation as well. The `Swagger` configuration is in `api/swagger/swagger.yaml`. By default the APIs are configured to both consume and produce `JSON` data format. The `paths` section of this configuration has all the routes (`/airports` for example). Under each route consists the supported HTTP operations such as `GET` and `POST` (`GET`, `POST`, `PATCH`, `PUT` and `DELETE` have been used in this `Swagger` config for demonstration).    

## Authorization
The Node Toolkit 0.0.1  uses ACL for authorization support and by default provides APIs for few authorization services.
- To create a role
- To delete a role
- To assign role to a user
- To remove role for a user
WIP.
