require('babel-register');
require('babel-polyfill');
require('./app.js');
